<?php
/**
 * Plugin Name:			HV Themes demo import
 * Plugin URI:			https://hvthemes.com/
 * Description:			Demo Import
 * Version:				  1.0
 * Author:				  HVThemesTeams
 * Author URI:			https://hvthemes.com/
 *
 * @package HVThemes_Demo_Importer
 * @category Core
 * @author HVThemesTeams
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Returns the main instance of HVThemes_Demo_Importer to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object HVThemes_Demo_Importer
 */
function HVThemes_Demo_Importer() {
	return HVThemes_Demo_Importer::instance();
} // End HVThemes_Demo_Importer()

HVThemes_Demo_Importer();

/**
 * Main HVThemes_Demo_Importer Class
 *
 * @class HVThemes_Demo_Importer
 * @version	1.0.0
 * @since 1.0.0
 * @package	HVThemes_Demo_Importer
 */
final class HVThemes_Demo_Importer {
	/**
	 * HVThemes_Demo_Importer The single instance of HVThemes_Demo_Importer.
	 * @var 	object
	 * @access  private
	 * @since 	1.0.0
	 */
	private static $_instance = null;

	/**
	 * The token.
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $token;

	/**
	 * The version number.
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $version;

	// Admin - Start
	/**
	 * The admin object.
	 * @var     object
	 * @access  public
	 * @since   1.0.0
	 */
	public $admin;

	/**
	 * Constructor function.
	 * @access  public
	 * @since   1.0.0
	 * @return  void
	 */
	public function __construct() {
		$this->token 			= 'hvthemes-demo-importer';
		$this->plugin_url 		= plugin_dir_url( __FILE__ );
		$this->plugin_path 		= plugin_dir_path( __FILE__ );
		$this->version 			= '1.4.29';

		define( 'FE_URL', $this->plugin_url );
		define( 'FE_PATH', $this->plugin_path );
		define( 'FE_VERSION', $this->version );	


		register_activation_hook( __FILE__, array( $this, 'install' ) );

		// Setup all the things
		add_action( 'init', array( $this, 'setup' ) );

	}

	/**
	 * Main HVThemes_Demo_Importer Instance
	 *
	 * Ensures only one instance of HVThemes_Demo_Importer is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @static
	 * @see HVThemes_Demo_Importer()
	 * @return Main HVThemes_Demo_Importer instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) )
			self::$_instance = new self();
		return self::$_instance;
	} // End instance()

	/**
	 * Cloning is forbidden.
	 *
	 * @since 1.0.0
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?' ), '1.0.0' );
	}

	/**
	 * Unserializing instances of this class is forbidden.
	 *
	 * @since 1.0.0
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?' ), '1.0.0' );
	}

	/**
	 * Installation.
	 * Runs on activation.
	 * @access  public
	 * @since   1.0.0
	 * @return  void
	 */
	public function install() {
	
	}



	/**
	 * Setup all the things.
	 * @return void
	 */
	public function setup() {
		$theme = wp_get_theme();

		if ( 'HV Themes' == $theme->name || 'hello-hv' == $theme->template ) {
		
				require_once( FE_PATH .'/hello-hv-demos.php' );

		}
		if ( 'HV Themes' == $theme->name || 'businest' == $theme->template ) {
		
				require_once( FE_PATH .'/businest-demos.php' );

		}
	}



} // End Class